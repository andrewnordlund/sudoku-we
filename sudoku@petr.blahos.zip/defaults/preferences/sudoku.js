// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.sudoku.description", "chrome://sudoku/locale/sudoku.properties");
pref("extensions.sudoku.sidebar.view", 1);
pref("extensions.sudoku.allowhard", false);
pref("extensions.sudoku.hinttips", true);
pref("extensions.sudoku.hlcross", true);
pref("extensions.sudoku.hlerrors", true);
